PCD Workbook: a study guide for the Google Cloud Professional Cloud Developer exam.

1. Open pcd-workbook.html in a web browser on a computer. It has the notes,
   practice questions, mock exams, and lab steps. Your progress
   saves in that browser only.
2. To do the labs, open a terminal in this folder. The labs call this folder
   the repository root. Start with pcd/labs/00-setup/README.md. The labs create
   resources in your own Google Cloud project, and those resources cost money.
