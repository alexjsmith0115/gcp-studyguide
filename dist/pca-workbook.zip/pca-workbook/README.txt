PCA Workbook: a study guide for the Google Cloud Professional Cloud Architect exam.

1. Open pca-workbook.html in a web browser on a computer. It has the notes,
   practice questions, mock exams, case studies, and lab steps. Your progress
   saves in that browser only.
2. To do the labs, open a terminal in this folder. The labs call this folder
   the repository root. Start with labs/00-setup/README.md. The labs create
   resources in your own Google Cloud project, and those resources cost money.
